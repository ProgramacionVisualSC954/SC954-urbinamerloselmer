﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtBusqueda = New TextBox()
        Label1 = New Label()
        btnBuscar = New Button()
        resultado = New Label()
        Label666 = New Label()
        SuspendLayout()
        ' 
        ' txtBusqueda
        ' 
        txtBusqueda.BackColor = Color.Chartreuse
        txtBusqueda.Location = New Point(112, 86)
        txtBusqueda.Margin = New Padding(2, 2, 2, 2)
        txtBusqueda.Name = "txtBusqueda"
        txtBusqueda.Size = New Size(348, 23)
        txtBusqueda.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.BackColor = Color.Black
        Label1.ForeColor = Color.Blue
        Label1.Location = New Point(214, 20)
        Label1.Margin = New Padding(2, 0, 2, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(146, 31)
        Label1.TabIndex = 1
        Label1.Text = "Search ciclo and debug"
        ' 
        ' btnBuscar
        ' 
        btnBuscar.BackColor = Color.Red
        btnBuscar.ForeColor = Color.Black
        btnBuscar.Location = New Point(241, 126)
        btnBuscar.Margin = New Padding(2, 2, 2, 2)
        btnBuscar.Name = "btnBuscar"
        btnBuscar.Size = New Size(98, 61)
        btnBuscar.TabIndex = 2
        btnBuscar.Text = "Buscar"
        btnBuscar.UseVisualStyleBackColor = False
        ' 
        ' resultado
        ' 
        resultado.AutoSize = True
        resultado.Location = New Point(258, 211)
        resultado.Margin = New Padding(2, 0, 2, 0)
        resultado.Name = "resultado"
        resultado.Size = New Size(41, 15)
        resultado.TabIndex = 3
        resultado.Text = "Label2"
        ' 
        ' Label666
        ' 
        Label666.AutoSize = True
        Label666.BackColor = SystemColors.Menu
        Label666.Location = New Point(49, 211)
        Label666.Name = "Label666"
        Label666.Size = New Size(150, 15)
        Label666.TabIndex = 4
        Label666.Text = "Resultado de tu busqueda: "
        ' 
        ' Form3
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(560, 270)
        Controls.Add(Label666)
        Controls.Add(resultado)
        Controls.Add(btnBuscar)
        Controls.Add(Label1)
        Controls.Add(txtBusqueda)
        Margin = New Padding(2, 2, 2, 2)
        Name = "Form3"
        Text = "Form3"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtBusqueda As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnBuscar As Button
    Friend WithEvents resultado As Label
    Friend WithEvents Label666 As Label
End Class

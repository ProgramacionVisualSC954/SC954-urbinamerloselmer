﻿Public Class Form2
    Dim productos As New List(Of String)()
    Dim precios As New List(Of Decimal)()

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click

        Dim precio As Decimal

        If txtNombreProducto.Text.Trim = "" Then

            MessageBox.Show("Ingrese el nombre del producto")

            txtNombreProducto.Focus()

            Exit Sub

        End If

        If Not Decimal.TryParse(txtPrecioProducto.Text, precio) Or precio <= 0 Then

            MessageBox.Show("Ingrese un precio válido")

            txtPrecioProducto.Clear()

            txtPrecioProducto.Focus()

            Exit Sub

        End If

        productos.Add(txtNombreProducto.Text)

        precios.Add(precio)

        lstProductos.Items.Add(txtNombreProducto.Text & " - " & precio.ToString("C"))

        Dim subtotalCalculado As Decimal = 0

        For Each p As Decimal In precios

            subtotalCalculado += p

        Next

        Dim descuento As Decimal = 0

        If productos.Count >= 3 Then

            descuento = subtotalCalculado * 0.05D

        End If

        subtotalCalculado -= descuento

        Dim ivaCalculado As Decimal = subtotalCalculado * 0.16D

        Dim totalCalculado As Decimal = subtotalCalculado + ivaCalculado

        Subtotal.Text = subtotalCalculado.ToString("C")

        iva.Text = ivaCalculado.ToString("C")

        total.Text = totalCalculado.ToString("C")

        txtNombreProducto.Clear()

        txtPrecioProducto.Clear()

        txtNombreProducto.Focus()

    End Sub

    Private Sub btnGenerar_Click(sender As Object, e As EventArgs) Handles btnGenerar.Click

        If productos.Count = 0 Then

            MessageBox.Show("No hay productos agregados")

            Exit Sub

        End If

        Dim ticket As String = ""
        Dim contador As Integer = 1

        Dim subtotalCalculado As Decimal = 0

        For Each precio As Decimal In precios

            subtotalCalculado += precio

        Next

        For i As Integer = 0 To productos.Count - 1

            ticket &= contador & ". " &
                      productos(i) & " - " &
                      precios(i).ToString("C") & vbCrLf

            contador += 1

        Next


        Dim descuento As Decimal = 0

        If productos.Count >= 3 Then

            descuento = subtotalCalculado * 0.05D

            subtotalCalculado -= descuento

        End If


        Dim ivaCalculado As Decimal = subtotalCalculado * 0.16D

        Dim totalCalculado As Decimal = subtotalCalculado + ivaCalculado

        ticket &= vbCrLf
        ticket &= "-----------------------------" & vbCrLf
        ticket &= "Subtotal: " & subtotalCalculado.ToString("C") & vbCrLf

        If descuento > 0 Then

            ticket &= "Descuento (5%): -" & descuento.ToString("C") & vbCrLf

        End If

        ticket &= "IVA: " & ivaCalculado.ToString("C") & vbCrLf
        ticket &= "Total: " & totalCalculado.ToString("C") & vbCrLf

        MessageBox.Show(ticket, "TICKET DE COMPRA")

    End Sub

End Class
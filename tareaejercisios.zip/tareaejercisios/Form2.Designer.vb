﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        txtNombreProducto = New TextBox()
        txtPrecioProducto = New TextBox()
        btnAgregar = New Button()
        btnGenerar = New Button()
        lstProductos = New ListBox()
        Subtotal = New Label()
        iva = New Label()
        total = New Label()
        Label5 = New Label()
        Label6 = New Label()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(27, 9)
        Label1.Margin = New Padding(2, 0, 2, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(112, 15)
        Label1.TabIndex = 0
        Label1.Text = "Generador de Ticket"
        ' 
        ' txtNombreProducto
        ' 
        txtNombreProducto.BackColor = SystemColors.WindowText
        txtNombreProducto.ForeColor = Color.Blue
        txtNombreProducto.Location = New Point(36, 59)
        txtNombreProducto.Margin = New Padding(2, 2, 2, 2)
        txtNombreProducto.Name = "txtNombreProducto"
        txtNombreProducto.Size = New Size(324, 23)
        txtNombreProducto.TabIndex = 1
        ' 
        ' txtPrecioProducto
        ' 
        txtPrecioProducto.BackColor = SystemColors.WindowText
        txtPrecioProducto.ForeColor = Color.Blue
        txtPrecioProducto.Location = New Point(36, 106)
        txtPrecioProducto.Margin = New Padding(2, 2, 2, 2)
        txtPrecioProducto.Name = "txtPrecioProducto"
        txtPrecioProducto.Size = New Size(324, 23)
        txtPrecioProducto.TabIndex = 2
        ' 
        ' btnAgregar
        ' 
        btnAgregar.BackColor = SystemColors.ControlText
        btnAgregar.ForeColor = Color.Blue
        btnAgregar.Location = New Point(398, 58)
        btnAgregar.Margin = New Padding(2, 2, 2, 2)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(109, 34)
        btnAgregar.TabIndex = 3
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = False
        ' 
        ' btnGenerar
        ' 
        btnGenerar.BackColor = SystemColors.ControlText
        btnGenerar.ForeColor = Color.Blue
        btnGenerar.Location = New Point(398, 95)
        btnGenerar.Margin = New Padding(2, 2, 2, 2)
        btnGenerar.Name = "btnGenerar"
        btnGenerar.Size = New Size(109, 34)
        btnGenerar.TabIndex = 4
        btnGenerar.Text = "Generar"
        btnGenerar.UseVisualStyleBackColor = False
        ' 
        ' lstProductos
        ' 
        lstProductos.BackColor = Color.Chartreuse
        lstProductos.ForeColor = SystemColors.ActiveCaptionText
        lstProductos.FormattingEnabled = True
        lstProductos.ItemHeight = 15
        lstProductos.Location = New Point(36, 151)
        lstProductos.Margin = New Padding(2, 2, 2, 2)
        lstProductos.Name = "lstProductos"
        lstProductos.Size = New Size(127, 79)
        lstProductos.TabIndex = 5
        ' 
        ' Subtotal
        ' 
        Subtotal.AutoSize = True
        Subtotal.BackColor = Color.Blue
        Subtotal.ForeColor = Color.White
        Subtotal.Location = New Point(291, 178)
        Subtotal.Margin = New Padding(2, 0, 2, 0)
        Subtotal.Name = "Subtotal"
        Subtotal.Size = New Size(41, 15)
        Subtotal.TabIndex = 6
        Subtotal.Text = "Label2"
        ' 
        ' iva
        ' 
        iva.AutoSize = True
        iva.BackColor = Color.Blue
        iva.ForeColor = Color.White
        iva.Location = New Point(369, 178)
        iva.Margin = New Padding(2, 0, 2, 0)
        iva.Name = "iva"
        iva.Size = New Size(41, 15)
        iva.TabIndex = 7
        iva.Text = "Label3"
        ' 
        ' total
        ' 
        total.AutoSize = True
        total.BackColor = Color.Blue
        total.ForeColor = Color.White
        total.Location = New Point(455, 178)
        total.Margin = New Padding(2, 0, 2, 0)
        total.Name = "total"
        total.Size = New Size(41, 15)
        total.TabIndex = 8
        total.Text = "Label4"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(36, 43)
        Label5.Margin = New Padding(2, 0, 2, 0)
        Label5.Name = "Label5"
        Label5.Size = New Size(103, 15)
        Label5.TabIndex = 9
        Label5.Text = "Nombre Producto"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(36, 89)
        Label6.Margin = New Padding(2, 0, 2, 0)
        Label6.Name = "Label6"
        Label6.Size = New Size(40, 15)
        Label6.TabIndex = 10
        Label6.Text = "Precio"
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(560, 270)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(total)
        Controls.Add(iva)
        Controls.Add(Subtotal)
        Controls.Add(lstProductos)
        Controls.Add(btnGenerar)
        Controls.Add(btnAgregar)
        Controls.Add(txtPrecioProducto)
        Controls.Add(txtNombreProducto)
        Controls.Add(Label1)
        Margin = New Padding(2, 2, 2, 2)
        Name = "Form2"
        Text = "Form2"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtNombreProducto As TextBox
    Friend WithEvents txtPrecioProducto As TextBox
    Friend WithEvents btnAgregar As Button
    Friend WithEvents btnGenerar As Button
    Friend WithEvents lstProductos As ListBox
    Friend WithEvents Subtotal As Label
    Friend WithEvents iva As Label
    Friend WithEvents total As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        txtNombre = New TextBox()
        txtPrecio = New TextBox()
        categoria = New Label()
        iva = New Label()
        preciofinal = New Label()
        btnClasificar = New Button()
        btnLimpiar = New Button()
        Label2 = New Label()
        Label3 = New Label()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(11, 9)
        Label1.Margin = New Padding(2, 0, 2, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(142, 15)
        Label1.TabIndex = 0
        Label1.Text = "Clasificador de Productos"
        ' 
        ' txtNombre
        ' 
        txtNombre.BackColor = SystemColors.WindowText
        txtNombre.ForeColor = SystemColors.Highlight
        txtNombre.Location = New Point(21, 95)
        txtNombre.Margin = New Padding(2, 2, 2, 2)
        txtNombre.Name = "txtNombre"
        txtNombre.Size = New Size(397, 23)
        txtNombre.TabIndex = 1
        ' 
        ' txtPrecio
        ' 
        txtPrecio.BackColor = SystemColors.WindowText
        txtPrecio.ForeColor = SystemColors.HotTrack
        txtPrecio.Location = New Point(21, 142)
        txtPrecio.Margin = New Padding(2, 2, 2, 2)
        txtPrecio.Name = "txtPrecio"
        txtPrecio.Size = New Size(397, 23)
        txtPrecio.TabIndex = 2
        ' 
        ' categoria
        ' 
        categoria.AutoSize = True
        categoria.Location = New Point(97, 175)
        categoria.Margin = New Padding(2, 0, 2, 0)
        categoria.Name = "categoria"
        categoria.Size = New Size(12, 15)
        categoria.TabIndex = 3
        categoria.Text = "-"
        ' 
        ' iva
        ' 
        iva.AutoSize = True
        iva.Location = New Point(269, 175)
        iva.Margin = New Padding(2, 0, 2, 0)
        iva.Name = "iva"
        iva.Size = New Size(12, 15)
        iva.TabIndex = 4
        iva.Text = "-"
        ' 
        ' preciofinal
        ' 
        preciofinal.AutoSize = True
        preciofinal.Location = New Point(422, 175)
        preciofinal.Margin = New Padding(2, 0, 2, 0)
        preciofinal.Name = "preciofinal"
        preciofinal.Size = New Size(12, 15)
        preciofinal.TabIndex = 5
        preciofinal.Text = "-"
        ' 
        ' btnClasificar
        ' 
        btnClasificar.BackColor = Color.Blue
        btnClasificar.ForeColor = Color.Cornsilk
        btnClasificar.Location = New Point(109, 192)
        btnClasificar.Margin = New Padding(2, 2, 2, 2)
        btnClasificar.Name = "btnClasificar"
        btnClasificar.Size = New Size(88, 48)
        btnClasificar.TabIndex = 6
        btnClasificar.Text = "Clasificar"
        btnClasificar.UseVisualStyleBackColor = False
        ' 
        ' btnLimpiar
        ' 
        btnLimpiar.BackColor = Color.Blue
        btnLimpiar.ForeColor = Color.Cornsilk
        btnLimpiar.Location = New Point(356, 192)
        btnLimpiar.Margin = New Padding(2, 2, 2, 2)
        btnLimpiar.Name = "btnLimpiar"
        btnLimpiar.Size = New Size(88, 48)
        btnLimpiar.TabIndex = 7
        btnLimpiar.Text = "Limpiar"
        btnLimpiar.UseVisualStyleBackColor = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Chartreuse
        Label2.Location = New Point(21, 79)
        Label2.Margin = New Padding(2, 0, 2, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(51, 15)
        Label2.TabIndex = 8
        Label2.Text = "Nombre"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Lime
        Label3.Location = New Point(21, 125)
        Label3.Margin = New Padding(2, 0, 2, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(40, 15)
        Label3.TabIndex = 9
        Label3.Text = "Precio"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(560, 270)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(btnLimpiar)
        Controls.Add(btnClasificar)
        Controls.Add(preciofinal)
        Controls.Add(iva)
        Controls.Add(categoria)
        Controls.Add(txtPrecio)
        Controls.Add(txtNombre)
        Controls.Add(Label1)
        Margin = New Padding(2, 2, 2, 2)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtPrecio As TextBox
    Friend WithEvents categoria As Label
    Friend WithEvents iva As Label
    Friend WithEvents preciofinal As Label
    Friend WithEvents btnClasificar As Button
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label

End Class

﻿Imports System.Reflection.Emit

Public Class Form1

    Dim operacion As String = ""
    Dim parentesisAbierto As Boolean = False

    Private Sub ActualizarResultado()

        Try

            Dim dt As New DataTable()
            Dim resultado = dt.Compute(operacion, Nothing)

            Label14.Text = resultado.ToString()

        Catch ex As Exception

            Label14.Text = "wait..."

        End Try

    End Sub

    Private Sub AgregarTexto(valor As String)

        operacion &= valor
        Label13.Text = operacion

        ActualizarResultado()

    End Sub

    'NUMEROS

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        AgregarTexto("1")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        AgregarTexto("2")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        AgregarTexto("3")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        AgregarTexto("4")
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        AgregarTexto("5")
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        AgregarTexto("6")
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        AgregarTexto("7")
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        AgregarTexto("8")
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        AgregarTexto("9")
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        AgregarTexto("0")
    End Sub

    'BORRAR TODO
    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click

        operacion = ""
        Label13.Text = ""
        Label14.Text = "0"
        parentesisAbierto = False

    End Sub

    'BORRAR UnO
    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click

        If operacion.Length > 0 Then

            operacion = operacion.Substring(0, operacion.Length - 1)

            Label13.Text = operacion

            If operacion = "" Then
                Label14.Text = "0"
            Else
                ActualizarResultado()
            End If

        End If

    End Sub

    ' ---------------- OPERADORES ----------------
    ' BUTTON 13 = +
    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        AgregarTexto("+")
    End Sub

    ' BUTTON 14 = -

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        AgregarTexto("-")
    End Sub

    ' BUTTON 15 = *

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        AgregarTexto("*")
    End Sub

    ' BUTTON 16 = /

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        AgregarTexto("/")
    End Sub

    'PARENTESIS
    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click

        If parentesisAbierto = False Then

            AgregarTexto("(")
            parentesisAbierto = True

        Else

            AgregarTexto(")")
            parentesisAbierto = False

        End If

    End Sub

    'IGUAL
    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        Try
            Dim dt As New DataTable()
            Dim resultado = dt.Compute(operacion, Nothing)

            Label14.Text = resultado.ToString()

            operacion = resultado.ToString()
            Label13.Text = operacion

        Catch ex As Exception

            Label14.Text = "Error"

        End Try

    End Sub

End Class
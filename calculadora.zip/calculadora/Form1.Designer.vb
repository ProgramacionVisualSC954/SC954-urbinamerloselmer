﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button1.Location = New System.Drawing.Point(6, 160)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(93, 38)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "1"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button2.Location = New System.Drawing.Point(110, 160)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(93, 38)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "2"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button3.Location = New System.Drawing.Point(209, 160)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(93, 38)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "3"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button4.Location = New System.Drawing.Point(6, 204)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(93, 38)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "4"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button5.Location = New System.Drawing.Point(110, 204)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(93, 38)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "5"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button6.Location = New System.Drawing.Point(209, 204)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(93, 38)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "6"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button7.Location = New System.Drawing.Point(6, 248)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(93, 38)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "7"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button8.Location = New System.Drawing.Point(110, 248)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(93, 38)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "8"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button9.Location = New System.Drawing.Point(209, 248)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(93, 38)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "9"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button10.Location = New System.Drawing.Point(110, 292)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(93, 38)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "0"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button11.Location = New System.Drawing.Point(306, 114)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(93, 38)
        Me.Button11.TabIndex = 10
        Me.Button11.Text = "C"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button12.Location = New System.Drawing.Point(207, 114)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(93, 38)
        Me.Button12.TabIndex = 11
        Me.Button12.Text = "c"
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button13.Location = New System.Drawing.Point(308, 292)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(93, 38)
        Me.Button13.TabIndex = 12
        Me.Button13.Text = "+"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button14.Location = New System.Drawing.Point(308, 248)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(93, 38)
        Me.Button14.TabIndex = 13
        Me.Button14.Text = "-"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button15.Location = New System.Drawing.Point(308, 204)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(93, 38)
        Me.Button15.TabIndex = 14
        Me.Button15.Text = "x"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button16.Location = New System.Drawing.Point(306, 160)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(93, 38)
        Me.Button16.TabIndex = 15
        Me.Button16.Text = "/"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button17.Location = New System.Drawing.Point(6, 292)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(93, 38)
        Me.Button17.TabIndex = 16
        Me.Button17.Text = "( )"
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button18.Location = New System.Drawing.Point(209, 292)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(93, 38)
        Me.Button18.TabIndex = 17
        Me.Button18.Text = "="
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.LimeGreen
        Me.Label13.Location = New System.Drawing.Point(29, 28)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(139, 42)
        Me.Label13.TabIndex = 20
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.LimeGreen
        Me.Label14.Location = New System.Drawing.Point(32, 89)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(136, 40)
        Me.Label14.TabIndex = 21
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Yellow
        Me.ClientSize = New System.Drawing.Size(412, 363)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
End Class
